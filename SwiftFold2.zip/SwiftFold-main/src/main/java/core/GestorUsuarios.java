/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package core;

import java.util.LinkedList;
import java.util.HashMap;

/**
 *
 * @author adria
 */

/*
Esta clase se encarga de efectuar las operaciones CRUD sobre los usuarios registrados en el sistema.
Trabaja de manera directa con metodos y estructuras de RegistroManager para mantener la consistencia y optimizacion de codigo.
 */
public class GestorUsuarios {

    private RegistroManager registroManager;

    public GestorUsuarios(RegistroManager registroManager) {
        this.registroManager = registroManager;
    }

    /**
     * Modifica los datos de un usuario existente.
     * 
     * @param emailActual el correo del usuario a modificar
     * @param nuevoUsuario el objeto Usuario con los nuevos datos
     * @return ValidationResult con los errores o éxito de la operación
     */
    
    public ValidationResult modificarUsuario(String emailActual, Usuario nuevoUsuario) {
        ValidationResult resultado = new ValidationResult();

        LinkedList<Usuario> lista = registroManager.getListaUsuarios();
        HashMap<String, Usuario> mapa = registroManager.getMapaUsuarios();

        Usuario usuarioExistente = mapa.get(emailActual);
        if (usuarioExistente == null) {
            resultado.addMessage("El usuario con ese correo no existe.");
            return resultado;
        }

        // Validaciones básicas
        if (!Usuario.validarEmail(nuevoUsuario.getEmail())) {
            resultado.addMessage("El nuevo correo no tiene un formato válido.");
        }

        if (!Usuario.validarTelefono(nuevoUsuario.getTelefono())) {
            resultado.addMessage("El nuevo número de teléfono es inválido.");
        }

        if (!Usuario.validarContrasena(nuevoUsuario.getHashContrasena())) {
            resultado.addMessage("La nueva contraseña no cumple los requisitos mínimos.");
        }

        if (!resultado.isSuccess()) {
            return resultado;
        }

        // Actualizar campos (excepto el hash, que se regenera)
        usuarioExistente.setNombre(nuevoUsuario.getNombre());
        usuarioExistente.setApellido(nuevoUsuario.getApellido());
        usuarioExistente.setEmail(nuevoUsuario.getEmail());
        usuarioExistente.setTelefono(nuevoUsuario.getTelefono());
        usuarioExistente.setDepartamento(nuevoUsuario.getDepartamento());
        usuarioExistente.setMunicipio(nuevoUsuario.getMunicipio());
        usuarioExistente.setDependencia(nuevoUsuario.getDependencia());
        usuarioExistente.setCargo(nuevoUsuario.getCargo());

        // Actualizar contraseña (hash nuevo)
        String nuevoHash = HashUtil.generarHash(nuevoUsuario.getHashContrasena());
        usuarioExistente.setHashContrasena(nuevoHash);

        // Actualizar rol
        usuarioExistente.setRol(nuevoUsuario.getRol());

        // Si el email cambia, actualizar el mapa
        if (!emailActual.equalsIgnoreCase(nuevoUsuario.getEmail())) {
            mapa.remove(emailActual);
            mapa.put(nuevoUsuario.getEmail(), usuarioExistente);
        }

        // Guardar cambios en archivo
        registroManager.guardarUsuariosEnArchivo();

        resultado.setSuccess(true);
        return resultado;
    }

    /**
     * Elimina un usuario completamente del sistema (memoria y archivo CSV).
     * 
     * @param email el correo del usuario a eliminar
     * @return ValidationResult con el resultado de la operación
     */
    
    public ValidationResult eliminarUsuario(String email) {
        ValidationResult resultado = new ValidationResult();

        LinkedList<Usuario> lista = registroManager.getListaUsuarios();
        HashMap<String, Usuario> mapa = registroManager.getMapaUsuarios();

        Usuario usuarioAEliminar = mapa.get(email);
        if (usuarioAEliminar == null) {
            resultado.addMessage("No existe un usuario con ese correo electrónico.");
            return resultado;
        }

        // Eliminar de las estructuras en memoria
        lista.remove(usuarioAEliminar);
        mapa.remove(email);

        // Guardar cambios en el archivo
        registroManager.guardarUsuariosEnArchivo();

        resultado.setSuccess(true);
        return resultado;
    }
}